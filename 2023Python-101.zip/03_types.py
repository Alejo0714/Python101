#String
my_name="Alejandro"
my_name='Ramiro'
print(f"Su nomnbre es {my_name}")
print(type(my_name))

#Integers
my_age = 35
print('Tu edad es ->', my_age)
print(type(my_age))

#Booleans
is_single= True
print(f"Es soltero? {is_single}")
print(type(is_single))

#input
my_age2 = input("Cual es tu edad?")
print("Tu edad es->",my_age2)
print(type(my_age2))