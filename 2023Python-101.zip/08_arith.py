#suma
print(10+65)
#resta
print(156-5)
#Multiplicacion
print(45*66.3)
#Division
print(1000/25)
#Concatenar con operador +
print('Hola'+'Alejo')
#Replicar texto con operador *
print('Gool!!'*3)
#Precision decimal con % (que arroja el residio de la division)
print(10%2) # la division es exacta por lo que da 0
print(10%3) # como la division no es exacta el nuemero mas bajo que puede llegar el tres es               9, el residuo final sera 1
print(26%3)
#Operador // otorga el numero entero de una division, si el resultado es decimal, da como resultado el numero entero sin el decimal
print(15//4)
#Operador ** es la exponencia de un numero indicado
print(2**4)

#Expresion Compleja:
print(2 ** 3 + 3 - 7 / 1 // 4)

"""
El orden de prioridad en la solucion aritmetica es asi
P : Parentesis
E : Exponentes
M : Multiplicacion
D : Division
A : Adicion
S : Sustraccion
"""
print(2**3) #Da el resultado de las multiplicaciones
print((7/1)//4) #Da el resultado de las dividiosiones
print(8+3-1) #Serian los valores finales
