text = 'Ella sabe Python'
print(text [0])
print(text [6])
#print(text [999])
size = len(text)
print ('El tamaño es : ', size)
print(text[size - 1])
print(text[-1]) #Este comando te da el ultimo digito de una cadena de texto

#SLICING
print(text[0:5])
print(text[10:16])
print(text[:5]) # al no indicar el numero inicial python asume que es desde el principio
print(text[7:]) # al no indicar el numero final python asume que es desde la posicion dada hasta el ulimo digito
print(text[10:16:1]) # El tercer parametro es el numero de saltos o posiciones que deseo extraer
print(text[10:16:2])
print(text[::2])
print(text[::-1]) #Este codigo permite reversar el texto que se posea
