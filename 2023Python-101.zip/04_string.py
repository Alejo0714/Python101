#Crear una variable
name="Nicolas"
last_name="Escobar Gonzalez"
print(name)
print(last_name)

full_name = name + " " +last_name
print(full_name)

quote= "I'm Alejo"
print(quote)

quote2= 'She said "Hello"'
print(quote2)

#Formato a variables y concatencaion
template= "Hola, mi nombre es " + name + " y me apellido " + last_name
print('v1',template)

template = "Hola, mi nombre es {} y mi apellido es  {}".format(name,last_name)
print('v2',template)

template = f"Hola mi nombre es {name}, y mi apellido es {last_name}"
print('v3',template)
