
#Como se modifica los directorios
person = {
  'name':'Daniel',
  'last_name':'Perdomo',
  'langs': ['python', 'JS'],
  'age': 35 
}
print(person)
person['name']='Camilo'
person['age'] -= 10 #le resta al mismo valor -10 años
person['langs'].append('ruby')

print(person)

del person['last_name'] #para eliminar datos de diccionario se usa el codigo del (delete)

person.pop('age') #igualmente elimina el campo requerido del diccionario

print('items') #retorna todos los elementos de un diccionario
print(person.items())

print('keys') #retorna los definiciones que tiene el diccionario
print(person.keys())

print('values') #retorna los valores que tiene el diccionario 
print(person.values())



print(person)
