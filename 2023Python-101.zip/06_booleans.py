is_single = True
print(type(is_single))

is_single = True
print(is_single)

#para invertir el valor de un boolean se puede incluir la palabra "not"

print (not True)
print (not False)

is_single = not is_single
print(is_single)
print( f"El valor verdadero es {is_single}")

#Tipos de Booleanos
print(bool(True),bool(False),bool(None))
print(bool(0),bool(-1),bool('Casa'),bool(24))
print(bool(0.0),bool(0.j))
print(True+False)
