matrix = [
  [1,2,3],
  [4,5,6],
  [7,8,9]  
]
print (matrix[0][2]) #El primer corchete da la posicion de la primera lista y el segundo la posicion del numero que hay en esa primera lista

for row in matrix:
  print(row)
  for column in row:
    print(column)
  