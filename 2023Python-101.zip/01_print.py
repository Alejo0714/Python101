print("Este es el archivo 01_print.py")
print ("Hola esto es PYTHON")

print("Hay que seguir adelante")

#Operaciones Matematicas en PYTHON

print(12+5)

print(10-5)

print(10*17)

print(240/12)


# Este hashtag se usa como comentario del codigo y sirve para documentación del programa
# Si se antepone el hashtag se ignora la linea

"""
Comentario de gran candtidad de contenido con tres comillas

"""

'''
Pueden ser tambien con el uso de comillas simples

'''