'''
for element in range (1, 21):
  print(element)
'''

mylist = [23,45,67,89,43]
for element in mylist:
  print(element)

my_tuple = ('Dani',"Ale","Lau")
for element in my_tuple:
  print(element)

producto = {
  'Name': 'Camisa',
           'Price': 45000,
            'Stock': 89
                     
           }
for key in producto:
  print(key, '->', producto[key])

for key, value in producto.items():
  print(key,'->',value)

people = [
  {
    'Name': 'Nico',
    'Age': 45
    
  },
  {
    'Name':'Samu',
    'Age': 38
    
  },
  {
    'Name':'Cami',
    'Age': 15 
   
  }  
]

for person in people:
  print('name->',person['Name'])