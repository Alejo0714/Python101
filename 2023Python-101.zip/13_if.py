#CONDICIOLNALES if
  #Siempre se comienza con una operacion booleana seguida de dos puntos y la evaluación:
if True:
  print('Deberia ejecutarse') 

if False:
  print('Nunca se ejecuta')

#Si el programa ya ejecuta y valida el primer bloque ya no corre el segundo, es decir, luego de encontrar el primer booleanon ya no imprime el segundo

#EJEMPLO 1
'''
pet =input('Cual es tu mascota favorita : ')
if pet == 'Perro':
  print('Eres un dog lover!!')
if pet =='Gato':
  print('Eres una cat lover!!')
'''
#EJEMPLO2
'''
stock = int(input ('Cual es tu stock actual? : '))
if stock >100 and stock<=1000:
  print('El stock es correcto')
else:
  print('No es valido el stock')
  '''

#EJEMPLO 3
 # Se usa el elif como mentodo de anidacion para varios if
'''
pet =input('Cual es tu mascota favorita : ')
if pet == 'Perro':
  print('Eres un dog lover!!')
elif pet =='Gato':
  print('Eres una cat lover!!')
elif pet == 'Pez':
  print('Eso no es una mascota :( ')
else: 
  print('Eres muy exotico') 
'''

  #PROYECTO
   #Elabora un programa el cual te permita decir si un procgrama es par o impar
validacion = int(input(' Ingresa el número que quieres validar: '))
if validacion % 2 == 0:
    print('Este numero es par')
else:
    print('Este es un número impar')
  

