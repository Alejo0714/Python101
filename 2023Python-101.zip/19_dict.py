my_dict ={}
print(type(my_dict))

my_dict ={ 
  'avion': 'Objeto volador',
  'name': 'Alejandro',
  'last_name': 'Espinosa',
  'age': 35
 
}

print(my_dict)
print(len(my_dict))
print(my_dict['avion'])
print(my_dict['age'])
print(my_dict.get('last_name')) # es una version similar a los corchetes
print(my_dict.get('2last_name')) # A diferenccia de la opcion de corchetes el GET no arroja error

print('avion' in my_dict)
print('No esta'  in my_dict)
