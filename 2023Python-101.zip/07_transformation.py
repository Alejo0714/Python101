name = 'Alejo'
print(type(name))
name = 12
print(type(name))
name = True
print(type(name))

print("Nicolas" + "Torre")
print(5 + 10)
print("Alejo" + " 12")

age = 12
print("Mi edad es " + str(age))
age = input("Cual es tu edad actual: ")
print(type(age))
age = int(age)
age = age + 10
print(f'Tu edad en 10 años sera {age}')

age = int(input("Ingresa tu edad exacta..."))
print(age)
print(type(age))


#Es buena practica al definir variables y funciones proporcionar directamente el tipo de dato poniendo ":" y el tipo de formato
def is_different(num1: int, num2: int) -> bool:
  return not True if num1 != num2 else not False


mynum1 = int(input('Ingrese un 1er número: '))
mynum2 = int(input('Ingrese un 2do número: '))

result = is_different(mynum1, mynum2)
print(result)
print(type(result))

