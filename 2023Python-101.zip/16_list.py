'''Lista = [1, 2, 3, 4, 5]

Puede ser modificada
Cada elemento esta separado por una coma
Puede contener todo tipo de datos
Metodos para listas
Lista.metodo(indice,elemento) o

Lista.metodo(elemento)

Metodos importantes
.count(elemento) cuenta cuantas veces un elemento esta en una lista
.extend(lista) permite extender una lista agregándole los elementos de otra lista
.pop() elimina y retorna el ultimo elemento de la lista
.reverse() reversa el orden de la lista
.sort() ordena la lista de manera ascendente o descendente

Actualizar un valor
Lista = [1, 2, 3, 4, 5]
Lista[0] = -8
Lista = [-8, 2, 3, 4, 5], resultado de la lista luego de actualizar el valor
Agregar un elemento
Lista.append(indice,elemento) o
Lista.append(elemento) en este caso el nuevo elemento se agrega al final de la lista
Eliminar un elemento
Lista.remove(indice, elemento)'''

numbers = [1,2,3,4]
print(numbers)
print(type(numbers))

tasks = ['lavar platos','barrer']
print(tasks)

types = [1, True, 'HJ']
print(types)
print(type(types))

print(tasks[1])


text='hola'

tasks[1] = 'Trapear'
print(tasks)
tasks[1]= 'Lavar ropa'
print(tasks)

print(numbers[:3])
print(True in types)
print('hola' in types)