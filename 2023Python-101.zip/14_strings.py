text ='Ella sabe programar en python'
'''
print('JavaScripit' in text)
print('python' in text)

if 'JA' in text:
  print('Elegiste bien')
else:
  print('Hay mejores Opciones')
'''
#Para hallar el tamaño de las cadenas se debe usar la formula len
size = len('amor')
print(size)

#para usra mayusculao o minuscula se usa al final de la variable .upper() o .lower()
print(text)
print(text.upper())
print(text.lower())

#Para contra un elemento dentro del texto se usa .count(())
print(text.count('a'))

#Para modificar el case de la lettra se usa el .swapcase()
print(text.swapcase())

#para validar la letra o numero por el cual comienza se usa el comando .stratswith
print(text.startswith('E'))

#para validar la letra o numero por el cual termina se usa el comando .endswith
print(text.endswith('E'))

#para remplazar un tesxtose usa el comando .replace(find,replace)
print(text.replace('Ella','Camila'))

text_2='este es un titulo'
print(text_2)
print(text_2.capitalize()) #Capitalize modifica la primera palabra por mayuscula
print(text_2.title()) #Title funciona como el proper de excel
print(text_2.isdigit()) #valida si el input es un digito
print('398'.isdigit())