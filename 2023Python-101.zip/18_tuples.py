numbers = (1, 2 , 3)
strings = ('Amor','Ayer','Hola','Ayer')

print(numbers)
print(type(numbers))
print(strings)
print(type(strings))

print('0->', strings[-1])

# La tupla es inmutable y no se puede aplicar elementos de CRUD como por ejemplo el append
print(strings)
print(strings.index('Hola')) #Encuentra la posicion del texto que se le indica
print(strings.count('Ayer')) #Cuenta los elementos dentro de la tupla

#Si se pueden hacer transformaciones en las tuplas
my_list = list(strings)
print(my_list)
print(type(my_list))

my_list[1]='Exnovia'
print(my_list)

my_tuple= tuple(my_list)
print(my_tuple)
print(type(my_tuple))