print("Este es la clase de variables")

#Esto es una variable de texto
my_name= "Alejandro Espinosa"
print(my_name)

#Esto es una variable númerica
my_age= 35
print(my_age)

my_name= "Alejandro Espinosa Diaz"
print("my_name is  ",my_name)

#input de Nombre
my_name = input("Cual es tu nombre?")
print("Usando input",my_name)

#input de Edad
my_age= input("Indica que edad tienes -->")
print("Tu edad es la siguiente",my_age)

#Truco usando 'f'
'''
Este truco permite mediante el uso de la letra f en una funcion print concatenar todo de una manera mas agil
'''
my_name2=input('¿Cual es tu segundo nombre?')
print(f"Su segundo nombre {my_name2} ha sido confirmado")
