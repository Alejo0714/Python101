#and
print("AND")
print('True and True =>', True and True)
print('True and False =>', True and False)
print('False and False =>', False and False)
print('False and True =>', False and True)

print(10 > 5 and 5<10)
print(10 > 5 and 5!=10)
print(10 >= 5 and 70<10)

stock=input('Ingrese el numero de stock : ')
stock = int(stock)

print(stock >= 100 and stock<=1000)

#OR
print("OR")
print('True or True =>', True or True)
print('True or False =>', True or False)
print('False or False =>', False or False)
print('False or True =>', False or True)

role= input('Digita el rol')
print(role == 'admin' or role == 'seller')