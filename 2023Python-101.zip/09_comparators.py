# Operador mayor que ">"
print(7>3)
# Operador menor que "<"
print(10<1.5)
# Operador mayor que ">="
print(15>=3)
# Operador menor que ">="
print(3.2<=3)
# Operador igualdas "=="
print(145==155)
print(155==155)
# Operador desigualdas "!="
print(155!=155)
print(155!=165)
# Operador igualdad con texto "=="
print("Alejo"=="alejo")
print("Marta"=="Marta")
# Operador Tipo de dato igualdad con texto "=="
print("1"==1)
# Operador Tipo de dato igualdad con variables "=="
age =18
print(age>=18)