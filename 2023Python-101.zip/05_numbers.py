lives = 3
print(type(lives))

age = 34
budget = 500

temperatura = 12.2 #Este es un tiipo de dato float
print(type(temperatura))

lives = 2
print(lives)
lives = 1
print(lives)

lives = 12 + 15
print (lives)

lives = lives - 1
print(lives)

lives -= 1
print(lives)

lives -= 5
print(lives)

lives += 2
print(lives)

number_a = 45000000000000000000000000000000.1
print(number_a)

number_b = 0.00000000000000000000000000000000045
print(number_b)

budget_jan = 21050
budget_feb = 15045
budget_mar = 45070
budget_quarter= (budget_feb+budget_jan+budget_mar)/3
print(float(budget_quarter))