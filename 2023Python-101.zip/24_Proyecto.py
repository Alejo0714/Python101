import random
options_computer = ('Water','Fire','Wind','Earth','Light')
options_user = ('water','fire','wind','earth')
rounds = 1
computer_wins= 0
user_wins=0

while True:

  print('*' * 10)
  print('ROUND #', rounds)
  print('*'*10)

  print('computer_wins', computer_wins)
  print('user wins:',user_wins)
  
  user_option = input('Choose your Element: ')
  user_option = user_option.lower()
  rounds += 1
  
  
  if not user_option in options_user:
    print('That is not valid element')
    continue
  
  computer_option = random.choice(options_computer)
  computer_option = computer_option.lower()
  
  print('User option -> ', user_option)
  print('Computer option -> ', computer_option)
  
  
  if user_option == computer_option:
    print('The battle has not winner')
    
  elif user_option=='wind':
    if computer_option=='water':
      print('Wind can beat Water')
      print('User wins')
      user_wins +=1
    elif computer_option == 'fire':
      print("Both elements are friendly, It's a Tie")
    else:
      print('Earth beat Wind')
      print('Computer wins')
      computer_wins +=1
  elif user_option == 'water':
    if computer_option == 'fire':
      print('Water can beat Fire')
      print('User wins')
      user_wins +=1
    elif computer_option == 'Earth':
      print('Both elemens get along')
    else:
      print('Water is defeated by Wind')
      print('Computer Wins')
      computer_wins +=1


  elif user_option=='fire':
    if computer_option=='earth':
      print(f'{user_option} can beat {computer_option}')
      print('User wins')
      user_wins +=1
    elif computer_option == 'wind':
      print("Both elements like each other")
    else:
      print(f'{computer_option} beat {user_option}')
      print('Computer wins')
      computer_wins +=1
  elif user_option == 'earth':
    if computer_option == 'wind':
      print(f'{user_option} can beat {computer_option}')
      print('User wins')
      user_wins +=1
    elif computer_option == 'water':
      print('Both elemens are good')
    else:
      print(user_option + "lose against" + computer_option )
      print('Computer Wins')
      computer_wins +=1


  if computer_wins ==3:
    print('Too bad-----The champion of the battle is the Computer---')
    break

  if user_wins ==2:
    print("Let's Celebrate you are the champion")
    break
  
