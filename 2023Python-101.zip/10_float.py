x = 3.3
y = 1.1 +2.2
print(x)
print(y)
print(x==y)

#esta comparacion no da exacta por la senibilidad de python
y_str =format(y,".2g") #Con este codigo le estoy indicando que solo se requiere 2 digitos
print("str =>",y_str)
print(y_str == str(x))

#Si se quiere resolver matematicamente se debe incluir una tolerancia

tolerance = 0.00001
print(abs(x-y)<tolerance)