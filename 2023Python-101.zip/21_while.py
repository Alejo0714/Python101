''' while True:
  print ('se ejecuta')

counter = 0

while counter <10:
  counter += 1
  print(counter)
 

counter = 0
while counter < 20:
  counter +=1
  if counter  == 15:
    break #ese comando rompe con la secuencia o flujo del codigo
  print(counter)



counter = 0
while counter < 20:
  counter +=1
  if counter <15:
    continue #saltar al siguiente ciclo oviando todo lo que hay siguiente al codigo
  print(counter)
 '''
contador = 0
y = int(input('numero de la tabla : '))
x = int(input('ingresa hasta que numero deseas multiplicar : '))

while contador < x:
  contador +=1;
  resultado = y * contador;
  print(f'{y} x  {contador} es igual a {resultado}')
  
